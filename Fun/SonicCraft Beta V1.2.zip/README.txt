SonicCraft Beta 1.2

Thank you for downloading!

SonicCraft Beta 1.2 contains:
SonicCraft Beta 1.2
	(This is the map)
SonicCraftV2.1S1.zip
	(This is the texture pack to be used with Sonic 1 levels)
SonicCraftV2.1S2.zip
	(This is the texture pack to be used with Sonic 2 levels)

Before you start, make sure you are using the SonicCraftV2.1S1 Texture Pack.

All rules will be stated in the map. Have fun, don't break the rules, and remember to give feedback on the forums.